Joseph Godlewski and Zhiting Zhu
CSE 461 A
README for submission 1:

For compilation and running, make sure you are in the base directory (the one with the build.xml file)

Compilation can be performed by running the command: ant compile
To run the program, use either the command: ant
or use the command: ant run

Both commands will compile and jar the source code before execution if those tasks
have not already been done. 

Our main class is: src/project1/Project1Main.java

Note that execution of our program takes ~10s because phaseB takes a while

please contact us if there are any issues:
joe3701@cs.washington.edu
zzt0215@cs.washington.edu
