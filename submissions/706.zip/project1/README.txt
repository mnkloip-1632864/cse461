Joseph Godlewski    Zhiting Zhu
joe3701             zzt0215
1021706             1030029

CSE 461 A
README for submission 1:

For compilation and running, unzip code.zip and make sure you are in the code directory (the directory with the build.xml file)

Compilation can be performed by running the command: ant compile
To run the program, use either the command: ant
or use the command: ant run

Both commands will compile and jar the source code before execution if those tasks
have not already been done. 

Our main class is: src/project1/Project1Main.java

Note that execution of our program takes ~10s because phaseB takes a while

please contact us if there are any issues:
joe3701@cs.washington.edu
zzt0215@cs.washington.edu
